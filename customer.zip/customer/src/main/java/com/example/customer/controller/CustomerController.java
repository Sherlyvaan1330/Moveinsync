package com.example.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.customer.model.Customer;
import com.example.customer.service.CustomerService;

@RestController
@RequestMapping("/api")
public class CustomerController {
        @Autowired
        CustomerService custService;
        
        @RequestMapping(value="/customers", method=RequestMethod.POST)
        public Customer createCustomer(@RequestBody Customer cust) {
            return custService.createCustomer(cust);
        }
        
        @RequestMapping(value="/customers", method=RequestMethod.GET)
        public List<Customer> readCustomers() {
            return custService.getCustomers();
        }

        @RequestMapping(value="/customers/{custId}", method=RequestMethod.PUT)
        public Customer readCustomers(@PathVariable(value = "custId") Long id, @RequestBody Customer custDetails) {
            return custService.updateCustomer(id, custDetails);
        }

        @RequestMapping(value="/customers/{custId}", method=RequestMethod.DELETE)
        public void deleteCustomers(@PathVariable(value = "custId") Long id) {
            custService.deleteCustomer(id);
        }

}
