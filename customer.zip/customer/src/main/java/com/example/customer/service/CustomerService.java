package com.example.customer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.customer.model.Customer;
import com.example.customer.repository.CustomerRepository;
import java.util.List;

@Service
public class CustomerService {

        @Autowired
            CustomerRepository custRepository; 
        
     // CREATE 
        public Customer createCustomer(Customer cust) {
            return custRepository.save(cust);
        }

        // READ
        public List<Customer> getCustomers() {
            return custRepository.findAll();
        }

        // DELETE
        public void deleteCustomer(Long custId) {
            custRepository.deleteById(custId);
        }
        
     // UPDATE
        public Customer updateCustomer(Long custId, Customer customerDetails) {
                Customer cust = custRepository.findById(custId).get();
                cust.setName(customerDetails.getName());
                cust.setMail(customerDetails.getMail());
                cust.setNum(customerDetails.getNum());
                cust.setCity(customerDetails.getCity());
                
                return custRepository.save(cust);                                
        }
}
